import React from "react";

export default function SecondTry() {
  return <div>hi SecondTry</div>;
}
