import React from "react";
import { useFormik } from "formik";
import { formSchema } from "../Schema/index.js";

const initialValues = {
  name: "",
  color: "",
  price: "",
  size: "",
  description: "",
};

function Corporate() {
  const { values, errors, handleBlur, touched, handleChange, handleSubmit } =
    useFormik({
      //useFormik is hook by formik, here we have to pass mainly two paramenters and that is initialValues and onSubmit
      initialValues: initialValues,
      validationSchema: formSchema,
      onSubmit: (values) => {
        console.log("console value:", values);
        console.log("console price:", values?.price);
        console.log("console size:", values?.size);
        console.log("console color:", values?.color);
      },
    });
  // console.log("console formik function", handleSubmit)
  console.log("console errors", errors);

  return (
    <>
      <form onSubmit={handleSubmit}>
        <h1 className="md:text-[20px] py-3">
          <b>Add Corporate data :</b>
        </h1>
        <div className="w-[65%] h-[fit-content] py-4 border-3 bg-blue-100">
          <div className="w-[100%] flex md:text-[17px] border-1 my-3">
            <div className="w-[40%]  flex justify-end">
              <label className="my-auto">Name of the product :</label>
            </div>
            <div className="w-[60%] justify-start ps-2">
              <input
                type="name"
                autoComplete="off"
                name="name"
                value={values.name}
                onChange={handleChange}
                className="w-[80%] rounded-[10px] border py-2 px-3 h-[auto]"
                placeholder="Enter the name product"
              />
              {errors.name && touched.name ? (
                <p className="text-red-700 ms-2">{errors.name}</p>
              ) : null}
            </div>
          </div>
          <div className="w-[100%] flex md:text-[17px] border-1 my-3">
            <div className="w-[40%] flex justify-end">
              <label className="my-auto">Description :</label>
            </div>
            <div className="w-[60%] justify-start ps-2">
              <input
                name="description"
                value={values.description}
                onChange={handleChange}
                className="w-[80%] rounded-[10px] border py-2 px-3"
                placeholder="Enter the name product"
              />
              {errors.description && touched.description ? (
                <p className="text-red-700 ms-2">{errors.description}</p>
              ) : null}
            </div>
          </div>
          <div className="w-[100%] flex md:text-[17px] my-3">
            <div className="w-[40%] flex justify-end">
              <label className="my-auto">Image of the product :</label>
            </div>
            <div className="w-[60%] justify-start ps-2">
              <input
                className="w-[80%] rounded-[10px] border py-2 px-3"
                placeholder="Enter the name product"
              />
            </div>
          </div>
          <div className="w-[100%] flex md:text-[17px] my-3">
            <div className="w-[40%] flex justify-end pe-2">
              <label className="my-auto">Available sizes :</label>
            </div>
            <div className="w-[60%] justify-start ps-2">
              <input
                name="size"
                value={values.size}
                onChange={handleChange}
                className="w-[80%] rounded-[10px] border py-2 px-3"
                placeholder="Enter the name product"
              />
              {errors.size && touched.size ? (
                <p className="text-red-700 ms-2">{errors.size}</p>
              ) : null}
            </div>
          </div>
          <div className="w-[100%] flex md:text-[17px] my-3">
            <div className="w-[40%] flex justify-end pe-2">
              <label className="my-auto">Available colors :</label>
            </div>
            <div className="w-[60%] justify-start ps-2">
              <input
                name="color"
                value={values.color}
                onChange={handleChange}
                className="w-[80%] rounded-[10px] border py-2 px-3"
                placeholder="Enter the name product"
              />
              {errors.color && touched.color ? (
                <p className="text-red-700 ms-2">{errors.color}</p>
              ) : null}
            </div>
          </div>
          <div className="w-[100%] flex md:text-[17px] my-3">
            <div className="w-[40%] flex justify-end pe-2">
              <label className="my-auto">Price :</label>
            </div>
            <div className="w-[60%] justify-start ps-2">
              <input
                name="price"
                value={values.price}
                onChange={handleChange}
                className="w-[80%] rounded-[10px] border py-2 px-3"
                placeholder="Enter the name product"
              />
              {errors.price && touched.price ? (
                <p className="text-red-700 ms-2">{errors.price}</p>
              ) : null}
            </div>
          </div>
          <div className="w-[100%] flex justify-center mt-3">
            <button
              type="submit"
              className="border rounded-full px-3 py-1 text-white text-[18px] bg-blue-600 "
            >
              Submit
            </button>
          </div>
        </div>
      </form>
    </>
  );
}

export default Corporate;
